# eBike-Lade-Limit für die Shelly-Steckdose (Plug S Gen3 / Gen2)

**Deutsch** · [English below](#english)

Das Skript läuft direkt auf der Steckdose. Kein Handy, keine App nötig.

## Zwei Arten zu laden

| Du schaltest ein … | Was passiert |
|---|---|
| **an der Taste der Steckdose** (oder Shelly-App, Zeitplan) | Die Steckdose lädt **1 Stunde 30 Minuten** und schaltet dann aus. |
| **mit der Webseite „eBike Ladeplaner"** („Nach Verbrauch") | Die Seite schickt Akku, Ladegerät, Ladestand und Ziel. Das Skript rechnet die Energie aus und schaltet beim Ziel ab. |

In beiden Fällen schaltet das Skript zusätzlich aus, wenn das Ladegerät 5 Minuten lang keinen Strom mehr
zieht (Akku voll). Bei der Webseite („Nach Verbrauch“) gibt es keine Zeitgrenze, es zählt nur die Energie.

Die 90 Minuten stellst du oben im Skript bei `buttonMinutes` ein.

## Einrichtung (einmalig, ca. 5 Minuten)

1. Shelly in dein Heim-WLAN bringen (Shelly-App oder Web-Oberfläche der Steckdose).
2. IP-Adresse der Steckdose im Router notieren, am besten eine feste IP vergeben.
3. IP im Browser öffnen → **Scripts** → **Create script**.
4. Den Inhalt von `01_lade_limit.js` einfügen.
5. Oben im Block `CONFIG` bei Bedarf Werte ändern (nur `buttonMinutes` ist für die Taste wichtig).
6. **Save** → **Start**, dann **Run on startup** aktivieren.

## Mit der Webseite

1. In der Liste der Skripte die **Nummer** dieses Skripts ablesen (meist 1) und auf der Seite unter
   „Skript-Nummer" eintragen, falls sie nicht 1 ist.
2. Auf der Seite IP eintragen, „Nach Verbrauch" wählen, „Ladevorgang starten" antippen.
3. Link: `http://IP/script/1/ebike?cap=500&pow=80&from=20&to=60`
   Ausschalten: `http://IP/script/1/ebike?on=0`

Die per Link gesetzten Werte gelten nur für diese Ladung.

### Profile und Batterieschutz
Jede Steckdose ist auf der Seite ein eigenes **Profil** (Auswahl oben rechts). Mehrere Shelly-Steckdosen sind möglich, jede mit eigener IP. Der **Batterieschutz** („Batterieschutz 100 % starten“) schaltet immer mit dem Timer-Link (`toggle_after`), unabhängig vom Abschaltmodus. Auch dafür gilt der Hinweis unten.

### „Nach Timer" auf der Seite
Dabei setzt der Link einen eigenen Timer (`toggle_after`). Das Skript lässt ihn in Ruhe und setzt kein
90-Minuten-Limit darüber. Falls deine Firmware den Timer nicht im Status meldet (`timer_duration`), kann es
sein, dass nach 90 Minuten abgeschaltet wird, auch wenn der Timer länger ist. Dann nimm lieber „Nach Verbrauch".

## Hinweise

- Dauer und Energie sind Schätzungen (85 % Wirkungsgrad, ab 80 % halbe Ladeleistung). `efficiency` und
  `taperFactor` im Skript anpassen, wenn der Akku nach einigen Ladungen zu früh oder spät abgeschaltet wird.
- Wird die Steckdose stromlos oder das Skript neu gestartet, ist die laufende Überwachung weg. Schalte dann
  einmal aus und wieder ein.
- Das Skript ersetzt keine Sicherheitsfunktionen, das Akku-Management von Bosch bleibt aktiv.
  Lade nicht unbeaufsichtigt.
- Nur dieses eine Skript verwenden (die frühere Datei `02_stop_bei_energie.js` entfällt).

## Ungetestet

Ich habe das Skript mit einer Simulation geprüft (Taste = 90 min, Link = Energiegrenze, Aus-Link),
aber nicht an einer echten Shelly-Steckdose. Teste zuerst mit einer Lampe oder kurzer Zeit
(z. B. `buttonMinutes: 2`) und schau im Skript-Fenster unter der Konsole nach den Meldungen.

---

<a id="english"></a>

# eBike charge limit for the Shelly plug (Plug S Gen3 / Gen2)

[Deutsch](#eBike-Lade-Limit-für-die-Shelly-Steckdose-plug-s-gen3--gen2)

The script runs on the plug itself. No phone or app needed.

## Two ways to charge

| You switch on … | What happens |
|---|---|
| **with the button on the plug** (or the Shelly app, a schedule) | The plug charges for **1 hour 30 minutes**, then switches off. |
| **with the "eBike Ladeplaner" web page** ("Nach Verbrauch" = by consumption) | The page sends battery, charger, current level and target. The script computes the energy and switches off at the target. |

In both cases the script also switches off when the charger draws no current for 5 minutes (battery full).
With the web page ("by consumption") there is no time limit, only the energy counts.

Set the 90 minutes at the top of the script in `buttonMinutes`.

## Setup (once, about 5 minutes)

1. Connect the Shelly to your home Wi-Fi (Shelly app or the plug's web interface).
2. Note the plug's IP address in your router, ideally assign a fixed IP.
3. Open the IP in a browser → **Scripts** → **Create script**.
4. Paste the contents of `01_lade_limit.js`.
5. Change values in the `CONFIG` block if needed (only `buttonMinutes` matters for the button).
6. **Save** → **Start**, then enable **Run on startup**.

## With the web page

1. Read the **number** of this script in the script list (usually 1) and enter it on the page under "Skript-Nummer" (script number) if it is not 1.
2. On the page enter the IP, choose "Nach Verbrauch", tap "Ladevorgang starten" (start charging).
3. Link: `http://IP/script/1/ebike?cap=500&pow=80&from=20&to=60`
   Switch off: `http://IP/script/1/ebike?on=0`

Values set via the link apply to this charge only.

### Profiles and battery protection
Each plug is its own **profile** on the page (selector at the top right). Several Shelly plugs are possible, each with its own IP. **Battery protection** ("Batterieschutz 100 % starten") always uses the timer link (`toggle_after`), whatever the shutoff mode. The note below applies to it as well.

### "Nach Timer" (by timer) on the page
The link sets its own timer (`toggle_after`). The script leaves it alone and sets no 90-minute limit over it. If your firmware does not report the timer in its status (`timer_duration`), the plug may switch off after 90 minutes even if the timer is longer. In that case use "Nach Verbrauch" instead.

## Notes

- Duration and energy are estimates (85 % efficiency, half charging power above 80 %). Adjust `efficiency` and `taperFactor` in the script if the battery switches off too early or too late after a few charges.
- If the plug loses power or the script restarts, the running monitoring is gone. Switch off and on once.
- The script is no safety device, Bosch's battery management stays active. Do not charge unattended.
- Use only this one script (the earlier file `02_stop_bei_energie.js` is gone).

## Untested

I checked the script with a simulation (button = 90 min, link = energy limit, off link), but not on a real Shelly plug. Test first with a lamp or a short time (e.g. `buttonMinutes: 2`) and watch the messages in the script window under the console.
