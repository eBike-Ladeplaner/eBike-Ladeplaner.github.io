// eBike Lade-Limit für Shelly (Gen2/Gen3, z. B. Plug S Gen3)
// ----------------------------------------------------------------
// Zwei Arten, die Steckdose einzuschalten:
//
//  A) OHNE Webseite (Taste an der Steckdose, Shelly-App, Zeitplan):
//     Die Steckdose lädt buttonMinutes Minuten (Standard 90 = 1 Stunde 30 Minuten)
//     und schaltet dann aus.
//
//  B) MIT Webseite "eBike Ladeplaner" ("Laden starten", Modus "Mit Skript"):
//     Die Seite schickt Akku, Ladegerät, Ladestand und Ziel. Das Skript rechnet die
//     Energie bis zum Ziel aus und schaltet ab, sobald sie erreicht ist.
//
// Bei beiden Arten schaltet das Skript außerdem ab, wenn das Ladegerät länger keinen
// Strom mehr zieht (Akku voll). Bei B gibt es keine Zeitgrenze, nur die Energie zählt.
//
// >>> HIER EINSTELLEN <<<
let CONFIG = {
  buttonMinutes: 90,    // Ladedauer, wenn du ohne Webseite einschaltest (A)
  capacityWh: 500,      // nur B: Werte, falls der Link der Seite etwas weglässt
  chargerW: 80,
  startPercent: 20,
  targetPercent: 60,
  efficiency: 0.85,     // Wirkungsgrad Ladegerät + Akku (Schätzwert)
  taperFrom: 80,        // ab diesem Ladestand lädt der Akku langsamer
  taperFactor: 0.5,     // dann nur noch so viel Leistung (0.5 = halbe)
  idleWatt: 3,          // darunter gilt das Ladegerät als "fertig"
  idleMinutes: 5,       // so lange unter idleWatt, dann Aus
  switchId: 0
};

let CHECK_MS = 10000;
let session = null;     // läuft nur, solange die Steckdose überwacht wird
let override = null;    // Werte, die per Link der Webseite gesetzt wurden
let idleTicks = 0;

function num(v, fallback) {
  let n = Number(v);
  return (n === n && n > 0) ? n : fallback;   // n === n filtert NaN
}

function estimate(cap, pow, from, to, eff) {
  if (to <= from) return null;
  let fastPct = Math.min(to, CONFIG.taperFrom) - from;
  if (fastPct < 0) fastPct = 0;
  let slowPct = to - Math.max(from, CONFIG.taperFrom);
  if (slowPct < 0) slowPct = 0;
  let fastWh = cap * fastPct / 100;
  let slowWh = cap * slowPct / 100;
  let hours = fastWh / pow + slowWh / (pow * CONFIG.taperFactor);
  let batWh = fastWh + slowWh;
  return { batWh: batWh, wallWh: batWh / eff, seconds: hours * 3600 };
}

function sw() {
  return Shelly.getComponentStatus("switch:" + JSON.stringify(CONFIG.switchId));
}

function switchOff(reason) {
  print("Aus: " + reason);
  session = null;
  override = null;
  idleTicks = 0;
  Shelly.call("Switch.Set", { id: CONFIG.switchId, on: false });
}

// A) Einschalten ohne Webseite: feste Ladedauer
function startButtonSession() {
  // Kurz warten: Ein Link mit eigenem Timer ("Nur Timer" der Seite) soll nicht auf 90 Minuten gekürzt werden.
  Timer.set(2000, false, function () {
    if (session || override) return;
    let st = sw();
    if (!st || !st.output) return;
    if (st.timer_duration) { print("Timer der Seite aktiv, kein Standard-Limit."); return; }
    session = { stopAtWh: 1e12, deadline: Date.now() + CONFIG.buttonMinutes * 60000 };
    idleTicks = 0;
    print("Standard-Ladung: " + CONFIG.buttonMinutes + " min");
  });
}

// B) Einschalten mit Webseite: Energie bis zum Ziel
function startEnergySession() {
  let o = override || {};
  let cap = num(o.cap, CONFIG.capacityWh);
  let pow = num(o.pow, CONFIG.chargerW);
  let from = Number(o.from);
  if (!(from >= 0)) from = CONFIG.startPercent;
  let to = num(o.to, CONFIG.targetPercent);

  let est = estimate(cap, pow, from, to, CONFIG.efficiency);
  if (!est) {
    print("Ziel liegt nicht über dem Startwert, kein Limit gesetzt.");
    return;
  }
  let st = sw();
  let base = (st && st.aenergy) ? st.aenergy.total : 0;
  session = {
    stopAtWh: base + est.wallWh,
    deadline: Date.now() + 1e13 // keine Zeitgrenze, nur Energie und Leerlauf zählen
  };
  idleTicks = 0;
  print("Start: " + Math.round(est.batWh) + " Wh in den Akku, ca. " +
        Math.round(est.seconds / 60) + " min, Abschaltung bei +" + Math.round(est.wallWh) + " Wh");
}

function startSession() {
  if (override) startEnergySession();
  else startButtonSession();
}

// Link der Webseite:
//   http://IP/script/NR/ebike?cap=500&pow=80&from=20&to=60   (setzt Werte und schaltet ein)
//   http://IP/script/NR/ebike?on=0                           (schaltet aus)
// NR ist die Nummer dieses Skripts in der Liste der Skripte (meist 1).
HTTPServer.registerEndpoint("ebike", function (req, res) {
  let p = {};
  let parts = (req.query || "").split("&");
  for (let i = 0; i < parts.length; i++) {
    let kv = parts[i].split("=");
    if (kv.length === 2) p[kv[0]] = kv[1];
  }
  res.code = 200;
  if (p.on === "0") {
    switchOff("per Link");
    res.body = "Steckdose aus";
    res.send();
    return;
  }
  override = { cap: p.cap, pow: p.pow, from: p.from, to: p.to };
  session = null;
  let st = sw();
  if (st && st.output) startEnergySession();                           // läuft schon: Limit neu setzen
  else Shelly.call("Switch.Set", { id: CONFIG.switchId, on: true });   // Handler startet die Überwachung
  res.body = "OK: Laden " + p.from + " bis " + p.to + " Prozent";
  res.send();
});

Shelly.addStatusHandler(function (e) {
  if (e.component !== "switch:" + JSON.stringify(CONFIG.switchId)) return;
  if (!e.delta || typeof e.delta.output === "undefined") return;
  if (e.delta.output === true) startSession();
  else { session = null; override = null; idleTicks = 0; }
});

Timer.set(CHECK_MS, true, function () {
  if (!session) return;
  let st = sw();
  if (!st || !st.output) { session = null; return; }

  if (st.aenergy && st.aenergy.total >= session.stopAtWh) {
    switchOff("Ladeziel erreicht");
    return;
  }
  if (Date.now() >= session.deadline) {
    switchOff(session.stopAtWh > 1e11 ? "Standard-Ladezeit abgelaufen" : "Zeitgrenze abgelaufen");
    return;
  }
  if (st.apower !== undefined && st.apower < CONFIG.idleWatt) {
    idleTicks++;
    if (idleTicks * CHECK_MS >= CONFIG.idleMinutes * 60000) switchOff("Ladegerät zieht keinen Strom mehr");
  } else {
    idleTicks = 0;
  }
});

// Falls die Steckdose beim Start des Skripts schon an ist, Limit direkt setzen.
let initial = sw();
if (initial && initial.output) startSession();
