// eBike Lade-Limit für Shelly (Gen2/Gen3, z. B. Plug S Gen3)
// ----------------------------------------------------------------
// Zwei Arten, die Steckdose einzuschalten:
//
//  A) OHNE Webseite (Taste an der Steckdose, Shelly-App, Zeitplan):
//     Die Steckdose lädt buttonMinutes Minuten (Standard 90 = 1 Stunde 30 Minuten)
//     und schaltet dann aus.
//
//  B) MIT Webseite "eBike Ladeplaner" ("Laden starten", Modus "Mit Skript"):
//     Die Seite schickt Akku, Ladegerät, Ladestand und Ziel. Das Skript rechnet die
//     Energie bis zum Ziel aus und schaltet ab, sobald sie erreicht ist.
//
// Bei beiden Arten schaltet das Skript außerdem ab, wenn das Ladegerät länger keinen
// Strom mehr zieht (Akku voll). Bei B gibt es keine Zeitgrenze, nur die Energie zählt.
//
// >>> HIER EINSTELLEN <<<
let CONFIG = {
  buttonMinutes: 90,    // Ladedauer, wenn du ohne Webseite einschaltest (A)
  capacityWh: 500,      // nur B: Werte, falls der Link der Seite etwas weglässt
  chargerW: 80,
  startPercent: 20,
  targetPercent: 60,
  efficiency: 0.85,     // Wirkungsgrad Ladegerät + Akku (Schätzwert)
  taperFrom: 80,        // ab diesem Ladestand lädt der Akku langsamer
  taperFactor: 0.5,     // dann nur noch so viel Leistung (0.5 = halbe)
  idleWatt: 3,          // darunter gilt das Ladegerät als "fertig"
  idleMinutes: 5,       // so lange unter idleWatt, dann Aus
  switchId: 0
};

let CHECK_MS = 10000;
let session = null;     // läuft nur, solange die Steckdose überwacht wird
let override = null;    // Werte, die per Link der Webseite gesetzt wurden
let idleTicks = 0;

function num(v, fallback) {
  let n = Number(v);
  return (n === n && n > 0) ? n : fallback;   // n === n filtert NaN
}

function estimate(cap, pow, from, to, eff) {
  if (to <= from) return null;
  let fastPct = Math.min(to, CONFIG.taperFrom) - from;
  if (fastPct < 0) fastPct = 0;
  let slowPct = to - Math.max(from, CONFIG.taperFrom);
  if (slowPct < 0) slowPct = 0;
  let fastWh = cap * fastPct / 100;
  let slowWh = cap * slowPct / 100;
  let hours = fastWh / pow + slowWh / (pow * CONFIG.taperFactor);
  let batWh = fastWh + slowWh;
  return { batWh: batWh, wallWh: batWh / eff, seconds: hours * 3600 };
}

function sw() {
  return Shelly.getComponentStatus("switch:" + JSON.stringify(CONFIG.switchId));
}

function switchOff(reason) {
  print("Aus: " + reason);
  session = null;
  override = null;
  idleTicks = 0;
  Shelly.call("Switch.Set", { id: CONFIG.switchId, on: false });
}

// A) Einschalten ohne Webseite: feste Ladedauer
function startButtonSession() {
  // Kurz warten: Ein Link mit eigenem Timer ("Nur Timer" der Seite) soll nicht auf 90 Minuten gekürzt werden.
  Timer.set(2000, false, function () {
    if (session || override) return;
    let st = sw();
    if (!st || !st.output) return;
    if (st.timer_duration) { print("Timer der Seite aktiv, kein Standard-Limit."); return; }
    session = { stopAtWh: 1e12, deadline: Date.now() + CONFIG.buttonMinutes * 60000 };
    idleTicks = 0;
    print("Standard-Ladung: " + CONFIG.buttonMinutes + " min");
  });
}

// B) Einschalten mit Webseite: Energie bis zum Ziel
function startEnergySession() {
  let o = override || {};
  let cap = num(o.cap, CONFIG.capacityWh);
  let pow = num(o.pow, CONFIG.chargerW);
  let from = Number(o.from);
  if (!(from >= 0)) from = CONFIG.startPercent;
  let to = num(o.to, CONFIG.targetPercent);

  let est = estimate(cap, pow, from, to, CONFIG.efficiency);
  if (!est) {
    print("Ziel liegt nicht über dem Startwert, kein Limit gesetzt.");
    return;
  }
  let st = sw();
  let base = (st && st.aenergy) ? st.aenergy.total : 0;
  session = {
    stopAtWh: base + est.wallWh,
    deadline: Date.now() + 1e13 // keine Zeitgrenze, nur Energie und Leerlauf zählen
  };
  idleTicks = 0;
  print("Start: " + Math.round(est.batWh) + " Wh in den Akku, ca. " +
        Math.round(est.seconds / 60) + " min, Abschaltung bei +" + Math.round(est.wallWh) + " Wh");
}

function startSession() {
  if (override) startEnergySession();
  else startButtonSession();
}

// Antwortseite im Browser (kleine HTML-Seite, im Skript nur ASCII, Sonderzeichen als HTML-Zeichen)
function page(kind, title, lines) {
  let col = kind === "ok" ? "#2fbf99" : (kind === "bad" ? "#f0a35a" : "#7b8782");
  let sym = kind === "ok" ? "&#10003;" : (kind === "bad" ? "!" : "&#9632;");
  let h = "<!doctype html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>" + title + "</title></head>" +
    "<body style=\"margin:0;background:#101614;color:#e6ece9;font-family:-apple-system,Segoe UI,Roboto,sans-serif;text-align:center;padding:48px 20px\">" +
    "<div style=\"width:64px;height:64px;border-radius:50%;background:" + col + ";color:#06241b;font-size:32px;font-weight:700;line-height:64px;margin:0 auto 16px\">" + sym + "</div>" +
    "<h1 style=\"font-size:24px;margin:0 0 12px\">" + title + "</h1>";
  for (let i = 0; i < lines.length; i++) {
    h += "<p style=\"font-size:17px;line-height:1.4;margin:10px 0;color:#c5d0cb\">" + lines[i] + "</p>";
  }
  return h + "</body></html>";
}

function reply(res, code, kind, title, lines) {
  res.code = code;
  res.headers = [["Content-Type", "text/html; charset=utf-8"]];
  res.body = page(kind, title, lines);
  res.send();
}

function two(n) { return (n < 10 ? "0" : "") + n; }

// Link der Webseite:
//   http://IP/script/NR/ebike?cap=500&pow=80&from=20&to=60&eta=18:36&tm=0   (setzt Werte und schaltet ein)
//   http://IP/script/NR/ebike?on=0                                          (schaltet aus)
// eta (voraussichtliches Ende) und tm (1 = erst morgen) sind nur für die Anzeige.
// NR ist die Nummer dieses Skripts in der Liste der Skripte (meist 1).
// Die Antwort ist eine kleine Seite mit der Rückmeldung, bei Fehlern mit einem klaren Satz.
HTTPServer.registerEndpoint("ebike", function (req, res) {
  let p = {};
  let parts = (req.query || "").split("&");
  for (let i = 0; i < parts.length; i++) {
    let kv = parts[i].split("=");
    if (kv.length === 2) p[kv[0]] = kv[1];
  }
  let end = "Du kannst dieses Fenster schlie&szlig;en.";
  if (!sw()) {
    reply(res, 500, "bad", "Schalten nicht m&ouml;glich",
      ["Die Steckdose hat den Befehl nicht ausgef&uuml;hrt.",
       "Pr&uuml;fe, ob der richtige Schalter eingestellt ist (switchId im Skript).", end]);
    return;
  }
  if (p.on === "0") {
    switchOff("per Link");
    reply(res, 200, "off", "Steckdose aus", ["Die Ladung wurde abgebrochen.", end]);
    return;
  }
  if (p.cap === undefined && p.pow === undefined && p.from === undefined && p.to === undefined) {
    reply(res, 400, "bad", "Es fehlen Angaben",
      ["Der Link enth&auml;lt keine Werte (Akku-Gr&ouml;&szlig;e, Leistung, Start und Ziel).",
       "&Ouml;ffne die Seite neu und tippe noch einmal auf &bdquo;Ladevorgang starten&ldquo;.", end]);
    return;
  }
  let from = Number(p.from);
  if (!(from >= 0)) from = CONFIG.startPercent;
  let to = num(p.to, CONFIG.targetPercent);
  if (!(to > from)) {
    reply(res, 400, "bad", "Ziel zu niedrig",
      ["Das Ziel (" + Math.round(to) + " %) liegt nicht &uuml;ber dem Startwert (" + Math.round(from) + " %).",
       "Pr&uuml;fe die beiden Werte auf der Seite.", end]);
    return;
  }
  override = { cap: p.cap, pow: p.pow, from: p.from, to: p.to };
  session = null;
  let st = sw();
  let title = "Ladung gestartet";
  if (st && st.output) { startEnergySession(); title = "Limit aktualisiert"; }   // läuft schon: Limit neu setzen
  else Shelly.call("Switch.Set", { id: CONFIG.switchId, on: true });          // Handler startet die Überwachung
  let info = "Die Steckdose schaltet nach Verbrauch ab";
  if (p.eta !== undefined) {
    let ev = p.eta.split(":");
    let hh = Number(ev[0]), mm = Number(ev[1]);
    if (ev.length === 2 && hh >= 0 && hh < 24 && mm >= 0 && mm < 60) {
      info += ", voraussichtlich <b>" + (p.tm === "1" ? "morgen " : "") + "gegen " + two(hh) + ":" + two(mm) + " Uhr</b>";
    }
  }
  reply(res, 200, "ok", title,
    ["<span style=\"font-size:34px;font-weight:700;color:#e6ece9\">" + Math.round(from) + " &rarr; " + Math.round(to) + " %</span>",
     info + ".", end]);
});

Shelly.addStatusHandler(function (e) {
  if (e.component !== "switch:" + JSON.stringify(CONFIG.switchId)) return;
  if (!e.delta || typeof e.delta.output === "undefined") return;
  if (e.delta.output === true) startSession();
  else { session = null; override = null; idleTicks = 0; }
});

Timer.set(CHECK_MS, true, function () {
  if (!session) return;
  let st = sw();
  if (!st || !st.output) { session = null; return; }

  if (st.aenergy && st.aenergy.total >= session.stopAtWh) {
    switchOff("Ladeziel erreicht");
    return;
  }
  if (Date.now() >= session.deadline) {
    switchOff(session.stopAtWh > 1e11 ? "Standard-Ladezeit abgelaufen" : "Zeitgrenze abgelaufen");
    return;
  }
  if (st.apower !== undefined && st.apower < CONFIG.idleWatt) {
    idleTicks++;
    if (idleTicks * CHECK_MS >= CONFIG.idleMinutes * 60000) switchOff("Ladegerät zieht keinen Strom mehr");
  } else {
    idleTicks = 0;
  }
});

// Falls die Steckdose beim Start des Skripts schon an ist, Limit direkt setzen.
let initial = sw();
if (initial && initial.output) startSession();
