# eBike-Lade-Limit für Tasmota-Steckdosen

**Deutsch** · [English below](#english)

Gilt für Steckdosen mit Tasmota und Verbrauchsmessung (Leistung und Energie).
Die Webseite „eBike Ladeplaner" erzeugt die Links dafür. Auf der Seite oben **Tasmota** wählen.

Voraussetzung: Tasmota ab Version 10, die Steckdose misst Energie (im Tasmota-Menü steht unter Information
ein Abschnitt mit Leistung und „Energy Today").

## Einrichtung (einmalig)

1. IP-Adresse der Steckdose im Browser öffnen, dann **Consoles -> Console**.
2. Diese Zeilen nacheinander eingeben (jeweils mit Enter bestätigen), siehe auch `befehle.txt`:

       TelePeriod 10
       Mem1 99999
       Rule1 ON ENERGY#Today>=%mem1% DO Backlog Power Off; Mem1 99999 ENDON
       Rule1 1
       PulseTime 5500
       Rule2 ON POWER1#STATE=0 DO PulseTime 5500 ENDON
       Rule2 1

   Was sie tun:
   - Die Steckdose meldet alle 10 Sekunden ihre Energie. `Rule1` schaltet ab, sobald die Energie seit dem Start
     den Wert in `Mem1` erreicht. `Mem1 99999` bedeutet „keine Grenze aktiv".
   - `PulseTime 5500` ist der Standard-Timer: **Schaltest du die Steckdose per Taste (oder Tasmota-Oberfläche)
     ein, schaltet sie nach 1 Stunde 30 Minuten selbst wieder aus.** (Tasmota rechnet Werte ab 112 als
     Sekunden + 100, also 5500 = 5400 s = 90 Minuten.)
   - `Rule2` setzt `PulseTime` nach jedem Ausschalten wieder auf 5500 zurück, damit ein Start von der Webseite
     (der einen anderen Timer setzt) die Taste nicht dauerhaft verändert.

## Benutzung

**Ohne Webseite:** Taste an der Steckdose drücken. Sie lädt 1 Std. 30 Min. und schaltet ab.

**Mit Webseite:**
1. Akku, Ladegerät und Ladestand einstellen, **Tasmota** und **Nach Verbrauch** wählen.
2. „Ladevorgang starten" antippen. Der Link setzt den Tageszähler auf 0, setzt die Energiegrenze, schaltet den
   Timer ab (`PulseTime 0`) und schaltet ein. Es gibt keine Zeitgrenze, nur die Energie zählt.
3. Die Regel schaltet beim Ziel ab, auch wenn dein Handy nicht mehr in der Nähe ist.

„Nach Timer" schaltet ohne Regel nur über die Zeit ab. Das ist ungenauer.

## Profile und Batterieschutz

Jede Steckdose ist auf der Seite ein eigenes **Profil** (Auswahl oben rechts), mehrere Tasmota-Steckdosen sind möglich. Der **Batterieschutz** („Batterieschutz 100 % starten“) schaltet immer über den Timer (`PulseTime`, bis zu 13 Stunden), unabhängig vom Abschaltmodus. Danach setzt `Rule2` die Taste wieder auf 90 Minuten zurück.

## Wichtig zu wissen

- Der Link der Seite setzt den Tageszähler bei jedem Start auf 0. Die Tagesstatistik von Tasmota ist dadurch
  nicht mehr aussagekräftig. Der Verlauf auf der Webseite ersetzt sie.
- Der Tageszähler setzt sich um Mitternacht zurück. Bei einer Ladung über Mitternacht wird die Grenze daher nicht mehr erreicht.
  Dann musst du von Hand abbrechen, es gibt keinen Sicherheits-Timer.
- „Ladevorgang abbrechen" auf der Seite setzt `PulseTime` auf 5500 und die Grenze zurück.
  Von Hand: `Backlog PulseTime 5500; Mem1 99999; Power Off`
- Schaltest du während einer Seiten-Ladung aus und nach dem Ausschalten wieder per Taste ein, gilt wieder
  die Standard-Zeit von 90 Minuten.
- Ein Tasmota-WLAN der Steckdose gibt es nur, wenn sie ihr Heim-WLAN nicht findet (Adresse meist
  `192.168.4.1`). Im Alltag nutzt du das Heim-WLAN.
- Von unterwegs kommst du an die Steckdose nur mit VPN ins Heimnetz. Eine Tasmota-Cloud gibt es nicht.
- Der Ladestand wird nicht gemessen, du gibst ihn selbst ein.
- Die Erkennung „Ladegerät ist fertig" aus dem Shelly-Skript ist hier nicht eingebaut.
- Heißt dein Relais nicht `POWER1`, sondern nur `POWER` (bei Steckdosen mit einem Relais möglich),
  ändere in Rule2 `POWER1#STATE` in `POWER#STATE`.

## Ungetestet

Ich habe das nicht an einer echten Tasmota-Steckdose ausprobiert. Die Befehle habe ich gegen die
Tasmota-Dokumentation geprüft (PulseTime, EnergyToday, Mem, Rules, Backlog), den Ablauf als Ganzes nicht.
Teste ihn zuerst mit einer Lampe oder einer kleinen Ladung. Im Tasmota-Menü unter *Consoles -> Console*
siehst du, wann die Regeln auslösen.

---

<a id="english"></a>

# eBike charge limit for Tasmota plugs

[Deutsch](#eBike-Lade-Limit-für-Tasmota-Steckdosen)

For plugs running Tasmota with energy monitoring (power and energy). The "eBike Ladeplaner" web page generates the links. On the page choose **Tasmota** at the top of "Steckdose" (plug).

Requirement: Tasmota 10 or newer, the plug measures energy (the Tasmota information page shows power and "Energy Today").

## Setup (once)

1. Open the plug's IP address in a browser, then **Consoles -> Console**.
2. Enter these lines one after another (confirm each with Enter), see also `befehle.txt`:

       TelePeriod 10
       Mem1 99999
       Rule1 ON ENERGY#Today>=%mem1% DO Backlog Power Off; Mem1 99999 ENDON
       Rule1 1
       PulseTime 5500
       Rule2 ON POWER1#STATE=0 DO PulseTime 5500 ENDON
       Rule2 1

   What they do:
   - The plug reports its energy every 10 seconds. `Rule1` switches off as soon as the energy since the start reaches the value in `Mem1`. `Mem1 99999` means "no limit active".
   - `PulseTime 5500` is the default timer: **if you switch the plug on with the button (or the Tasmota interface), it switches itself off after 1 hour 30 minutes.** (Tasmota treats values from 112 as seconds + 100, so 5500 = 5400 s = 90 minutes.)
   - `Rule2` resets `PulseTime` to 5500 after every switch-off, so a start from the web page (which sets a different timer) does not permanently change the button.

## Usage

**Without the web page:** press the button on the plug. It charges 1 h 30 min and switches off.

**With the web page:**
1. Set battery, charger and charge level, choose **Tasmota** and **Nach Verbrauch** (by consumption).
2. Tap "Ladevorgang starten" (start charging). The link resets the daily counter to 0, sets the energy limit, disables the timer (`PulseTime 0`) and switches on. There is no time limit, only the energy counts.
3. The rule switches off at the target, even if your phone is no longer nearby.

"Nach Timer" (by timer) switches off by time only, without the rule. This is less exact.

## Profiles and battery protection

Each plug is its own **profile** on the page (selector at the top right), several Tasmota plugs are possible. **Battery protection** ("Batterieschutz 100 % starten") always switches via the timer (`PulseTime`, up to 13 hours), whatever the shutoff mode. Afterwards `Rule2` resets the button to 90 minutes.

## Good to know

- The page's link resets the daily counter at every start. Tasmota's daily statistics are therefore no longer meaningful. The history on the web page replaces them.
- The daily counter resets at midnight. For a charge across midnight the limit is therefore not reached. Then you have to cancel by hand, there is no safety timer.
- "Ladevorgang abbrechen" (cancel) on the page sets `PulseTime` to 5500 and resets the limit. By hand: `Backlog PulseTime 5500; Mem1 99999; Power Off`
- If you switch off during a charge started from the page and switch on again with the button afterwards, the default of 90 minutes applies again.
- A Tasmota Wi-Fi of the plug exists only if it cannot find its home Wi-Fi (address usually `192.168.4.1`). Day to day you use the home Wi-Fi.
- From away you only reach the plug with a VPN into your home network. There is no Tasmota cloud.
- The charge level is not measured, you enter it yourself.
- The "charger is done" detection from the Shelly script is not built in here.
- If your relay is called `POWER` instead of `POWER1` (possible for single-relay plugs), change `POWER1#STATE` to `POWER#STATE` in Rule2.

## Untested

I have not tried this on a real Tasmota plug. I checked the commands against the Tasmota documentation (PulseTime, EnergyToday, Mem, Rules, Backlog), but not the whole flow. Test it first with a lamp or a small charge. In the Tasmota menu under *Consoles -> Console* you can see when the rules fire.
