# eBike-Ladeplaner – alle Dateien

**Deutsch** · [English below](#english)

| Ordner | Wofür |
|---|---|
| `1_Webseite_GitHub` | Die Seite zum Hochladen bei GitHub Pages (Startbildschirm-App, auch offline). Anleitung in der README dort (Deutsch und Englisch). |
| `2_Shelly` | Skript für die Shelly-Steckdose (Taste = 1 Std. 30 Min., Webseite = genau bis zum Ziel). README auf Deutsch und Englisch. |
| `3_Tasmota` | Befehle für Tasmota-Steckdosen (gleiche Taste-Funktion über `PulseTime 5500`). README auf Deutsch und Englisch. |

Neu in dieser Version:
- **Version 79 (17.11.2026):**
  - **Karte „Nach dem Laden“ entfernt.** Eingetragen wird über „Eintragen“ in der Karte oben, die das Pop-up öffnet. Korrigieren kannst du unter „Alle Ladungen anzeigen“ mit „Ändern“.
  - **Pop-up „Ladung eintragen“ kompakter:** Es steht ganz oben, mit engeren Abständen, und lässt sich scrollen. So verdeckt die Tastatur den Speichern-Knopf nicht mehr.
  - **Link ganz unten:** „Zum Home-Bildschirm hinzufügen“ (iPhone) bzw. „Zum Startbildschirm hinzufügen“ (Android) zeigt die Installationskarte wieder, falls du sie weggeklickt hast. Nicht am Computer und nicht in der installierten App.
  - **„Aus Versehen gelöscht?“:** Einklappbarer Hinweis unter „Alle Ladungen anzeigen“: Sicherungsdatei mit „Aus Datei wiederherstellen“ neu einlesen.
- **Version 78 (17.11.2026):** Tasmota im „WLAN der Steckdose“: Der Hinweis nennt jetzt die richtige Adresse 192.168.4.1 (Shelly: 192.168.33.1). Die Links nutzten sie schon vorher.
- **Version 77 (17.11.2026):**
  - **Shelly „Nach Verbrauch“:** Die Steckdose zeigt nach dem Tippen eine kleine Seite („Ladung gestartet“ mit Bereich und voraussichtlicher Zeit, „Steckdose aus“) und klare Fehlerseiten („Es fehlen Angaben“, „Schalten nicht möglich“, „Ziel zu niedrig“). **Das Shelly-Skript `01_lade_limit.js` muss dafür neu eingefügt werden.** Bei Shelly entfällt der Hinweis zum 2-Sekunden-Fenster (bei Tasmota bleibt er).
  - **Batterieschutz:** Graue Zeile „Batterieschutz: noch N Ladestarts“ auf der Hauptseite.
  - **„fertig morgen gegen HH:MM Uhr“,** wenn die Ladung nicht am selben Tag endet.
  - **Installationskarte:** iPhone: Text mit „Teilen-Fenster öffnen“ / „Später“. Android: „Installieren“ / „Nein danke“ (Fallback: Tipp mit Menü ⋮ und „OK“). Nicht am Computer und nicht, wenn die Seite schon als App läuft.
- **Version 76 (17.11.2026):**
  - **Sicherung aufgeräumt:** Unter „Sicherung“ steht eine orange Zeile („Noch nie gesichert · 5 Ladungen offen“), die Erklärung liegt hinter „Mehr zur Sicherung“. Der orangefarbene Doppelhinweis im Verlauf ist weg.
  - **„Nach dem Laden“ einklappbar:** Die Karte ist zu („Keine Ladung gemerkt“) und öffnet sich von selbst, wenn eine Ladung auf den Eintrag wartet oder „Eintragen“ getippt wird.
  - **„Ändern“ im Verlauf:** Unter „Alle Ladungen anzeigen“ hat jeder Eintrag „Ändern“ (nur der erreichte Ladestand, das Lernen nutzt den neuen Wert) und „Löschen“, untereinander.
  - **Rückfrage:** Liegt der erreichte Ladestand mehr als 20 Prozentpunkte unter dem Ziel, fragt die Seite „Wirklich … % speichern?“ („Nein, ändern“ / „Ja, speichern“).
  - **Temperatur:** Unter 0 °C oder über 40 °C erscheint eine Warnung (Bosch nennt für das Laden 0 bis 40 °C), ohne Sperre. „Kein Standort freigegeben …“ steht nur, solange das Temperaturfeld leer ist.
  - **Bildschirm bleibt an,** solange die Uhr läuft und die Seite sichtbar ist (wenn der Browser es erlaubt).
  - Texte gekürzt: Kurzanleitung, Hinweise, Lernkurve, Wirkungsgrad.
- **Profile:** Oben rechts wählst du das Profil. Jedes Profil ist eine Steckdose mit einem Akku und einem Ladegerät. Weitere Profile legst du mit „+ Profil hinzufügen“ an, ändern und löschen geht unter „Steckdose“. Mehrere Profile können gleichzeitig laden. Jede Ladung merkt sich ihr Profil. Der Verlauf und das Lernen gelten pro Profil: Jedes Profil sammelt und lernt nur aus seinen eigenen Ladungen.
- **Batterieschutz:** Unter „Akku & Ladegerät“ stellst du ein (voreingestellt: 10), nach wie vielen Ladestarts eine Ladung auf 100 % laufen soll (Balancing). Dann heißt der Knopf „Batterieschutz 100 % starten“ und startet einen Timer: Charger 2 A 13 Std., 4 A 8 Std., 6 A und 12 A 6 Std. Diese Ladung kommt nicht in den Verlauf.
- **Außentemperatur:** Die Seite trägt sie beim Öffnen von selbst ein (Internet und Standortfreigabe nötig). Der Knopf „Außentemperatur holen“ ist weg. Während der Suche zeigt ein kleiner Kreisel „Außentemperatur wird gesucht …“; bei Fehlschlag gibt es bis zu 3 Versuche und eine genaue Meldung (kein Standort, kein Internet, Wetterdienst nicht erreichbar). Bei Rückkehr in die Seite wird es erneut versucht. Das Feld lässt sich überschreiben.
- **Sicherung:** Die Datei enthält jetzt auch alle Profile mit ihren Einstellungen (Steckdose, IP, Akku, Ladegerät, Batterieschutz, Wirkungsgrad, Modus, letzter Ladestand). Alte Sicherungen lassen sich weiter einlesen; ihre Ladungen gehören dann zum gewählten Profil, und ist dort noch kein Akku/Ladegerät gewählt, werden Akku, Ladegerät, Kapazität und Leistung aus der jüngsten Ladung übernommen. Der Zählerstand des Batterieschutzes und die Temperatur werden nicht gesichert. Sind 3 oder mehr Ladungen seit der letzten Sicherung nicht als Datei gesichert, steht oben in einer kleinen Karte ein orangefarbener Hinweis mit der Zahl, dem Datum der letzten Sicherung und dem Knopf „Sichern“. Dabei springt die Seite nicht nach unten, die Rückmeldung erscheint in der Karte. Ist eine Ladung fertig und nicht gespeichert, steht dort auch „Eintragen“: Es öffnet ein Fenster, in dem du den erreichten Ladestand einträgst („Speichern“, „Abbrechen“, „Ladung verwerfen“ mit zweitem Tippen zur Bestätigung).
- **Zwei Korrekturfaktoren:** einer für 0 bis 80 %, einer für 80 bis 100 %, die Zeiten werden addiert. Jede gespeicherte Ladung füttert den Bereich, den sie berührt. Der Faktor ab 80 % wird erst ab 3 Ladungen über 80 % genutzt (vorher ×1,00). Das Temperaturmodell und die Lernkurve gelten nur bis 80 %. Tipp: Lade ab und zu von 80 auf 100 %.
- **Sprache:** Ganz unten auf der Seite wählst du „DE | EN“. Alle Texte gibt es auf Deutsch und Englisch. Beim ersten Öffnen richtet sich die Sprache nach dem Browser, danach gilt deine Wahl.
- Der Ordner `4_Einzeldatei` gibt es nicht mehr.

Früher dazugekommen: Charger 12 A (Leistung je Akku), Eingabefelder statt Schieberegler, „Laden bis“ 60 %, Taste an der Steckdose = 90 Minuten, Lernmodell mit Temperatur und Lernkurve, Anzeige „Im Akku jetzt / Dazu geladen / Im Akku danach“, Schutz-Overlay beim Zurückkehren in die Seite, Version unten auf der Seite.

Bedienung: Ein Knopf „Ladevorgang starten“ / „Ladevorgang abbrechen“. Beim Antippen geht der Befehl an die Steckdose (bei Tasmota erscheint dafür etwa 2 Sekunden ein kleines Fenster, das sich selbst schließt; bei Shelly zeigt die Steckdose eine kleine Antwortseite). Abbrechen schaltet die Steckdose aus und verwirft die gemerkte Ladung ohne Verlaufseintrag. Nach dem Laden tippst du oben auf „Eintragen“ und trägst im Pop-up nur den erreichten Ladestand ein.

Wichtig: Nichts davon ist an echter Shelly-/Tasmota-Hardware oder auf einem echten Handy getestet. Die Leistungswerte des Charger 12 A sind Näherungen aus Bosch-Ladezeiten.

---

<a id="english"></a>

# eBike Ladeplaner – all files

[Deutsch](#ebike-ladeplaner--alle-dateien)

| Folder | Purpose |
|---|---|
| `1_Webseite_GitHub` | The page to upload to GitHub Pages (home-screen app, works offline). Instructions in the README there (German and English). |
| `2_Shelly` | Script for the Shelly plug (button = 1 h 30 min, web page = exactly up to the target). README in German and English. |
| `3_Tasmota` | Commands for Tasmota plugs (same button function via `PulseTime 5500`). README in German and English. |

New in this version:
- **Version 79 (17 Nov 2026):**
  - **"Nach dem Laden" (after charging) card removed.** You enter the level via "Eintragen" (enter) in the card at the top, which opens the pop-up. You can correct it under "Show all charges" with "Change".
  - **Pop-up "Ladung eintragen" more compact:** It sits at the very top, with tighter spacing, and can scroll. The keyboard no longer hides the save button.
  - **Link at the very bottom:** "Add to Home Screen" (iPhone) or "Add to Home screen" (Android) shows the install card again if you dismissed it. Not on a computer and not in the installed app.
  - **"Deleted by mistake?":** Collapsible note under "Show all charges": read your backup file in again with "Restore from file".
- **Version 78 (17 Nov 2026):** Tasmota on the plug's own Wi-Fi: the note now shows the correct address 192.168.4.1 (Shelly: 192.168.33.1). The links already used it before.
- **Version 77 (17 Nov 2026):**
  - **Shelly "Nach Verbrauch" (by consumption):** After tapping, the plug shows a small page ("Ladung gestartet" (charge started) with range and expected time, "Steckdose aus" (plug off)) and clear error pages ("Es fehlen Angaben" (details missing), "Schalten nicht möglich" (cannot switch), "Ziel zu niedrig" (target too low)). **For this, paste the Shelly script `01_lade_limit.js` again.** For Shelly the hint about the 2-second window is gone (it stays for Tasmota).
  - **Battery protection:** Grey line "Batterieschutz: noch N Ladestarts" (N charge starts left) on the main page.
  - **"done tomorrow around HH:MM"** when the charge does not end on the same day.
  - **Install card:** iPhone: text with "Teilen-Fenster öffnen" (open share sheet) / "Später" (later). Android: "Installieren" (install) / "Nein danke" (no thanks); fallback: a tip with the menu ⋮ and "OK". Not on a computer and not if the page already runs as an app.
- **Version 76 (17 Nov 2026):**
  - **Backup tidied:** Under "Sicherung" (backup) there is one orange line ("Never backed up · 5 charges open"); the explanation is behind "More about the backup". The duplicate orange hint in the history is gone.
  - **"Nach dem Laden" (after charging) collapsible:** The card is closed ("No charge remembered") and opens by itself when a charge waits for its entry or "Eintragen" (enter) is tapped.
  - **"Change" in the history:** Under "Show all charges" each entry has "Change" (only the level reached; learning uses the new value) and "Delete", one below the other.
  - **Confirmation:** If the level reached is more than 20 percentage points below the target, the page asks "Really save … %?" ("No, change" / "Yes, save").
  - **Temperature:** Below 0 °C or above 40 °C a warning appears (Bosch gives 0 to 40 °C for charging), no blocking. "No location permission given …" only shows while the temperature field is empty.
  - **Screen stays on** while the clock runs and the page is visible (if the browser allows it).
  - Texts shortened: quick guide, hints, learning curve, efficiency.
- **Profiles:** Choose the profile at the top right. Each profile is one plug with one battery and one charger. Add profiles with "+ Profil hinzufügen" (add profile); rename or delete them under "Steckdose" (plug). Several profiles can charge at the same time. Each charge remembers its profile. History and learning are per profile: each profile collects and learns only from its own charges.
- **Battery protection:** Under "Akku & Ladegerät" (battery and charger) set (default: 10) after how many charge starts a charge to 100 % should run (balancing). Then the button reads "Batterieschutz 100 % starten" and starts a timer: Charger 2 A 13 h, 4 A 8 h, 6 A and 12 A 6 h. This charge is not saved to the history.
- **Outdoor temperature:** The page fills it in by itself when opened (needs internet and location permission). The "Außentemperatur holen" button is gone. While searching, a small spinner shows "Looking for the outdoor temperature …"; on failure it tries up to 3 times and gives a specific message (no location, no internet, weather service unreachable). It tries again when you return to the page. You can overwrite the field.
- **Backup:** The file now also contains all profiles with their settings (plug, IP, battery, charger, battery protection, efficiency, mode, last charge level). Old backups can still be imported; their charges then belong to the selected profile, and if no battery/charger is chosen there yet, battery, charger, capacity and power are taken from the latest charge. The battery-protection counter and the temperature are not backed up. If 3 or more charges have not been backed up as a file since the last backup, an orange notice in a small card at the top shows the number, the date of the last backup and a "Back up" button. The page does not jump down; the feedback appears in the card. If a charge is finished and not saved, the card also shows "Enter": it opens a window where you enter the level reached ("Save", "Cancel", "Discard charge" with a second tap to confirm).
- **Two correction factors:** one for 0 to 80 %, one for 80 to 100 %, the times are added. Each saved charge feeds the range it touches. The factor above 80 % is only used from 3 charges above 80 % (before that ×1.00). The temperature model and learning curve apply to the range up to 80 % only. Tip: charge from 80 to 100 % now and then.
- **Language:** At the very bottom of the page choose “DE | EN”. All texts exist in German and English. On first opening the language follows the browser, afterwards your choice applies.
- The folder `4_Einzeldatei` (single file) no longer exists.

Added earlier: Charger 12 A (power per battery), input fields instead of sliders, "Laden bis" (charge to) 60 %, button on the plug = 90 minutes, learning model with temperature and learning curve, display "in battery now / added / in battery after", protective overlay when returning to the page, version at the bottom of the page.

Usage: One button "Ladevorgang starten" (start charging) / "Ladevorgang abbrechen" (cancel). Tapping it sends the command to the plug (Tasmota: a small window for about 2 seconds that closes itself; Shelly: the plug shows a small reply page). Cancel switches the plug off and discards the remembered charge without a history entry. After charging, tap "Eintragen" (enter) at the top and enter only the level reached in the pop-up.

Important: None of this is tested on real Shelly/Tasmota hardware or on a real phone. The power values of the Charger 12 A are approximations from Bosch charging times.
