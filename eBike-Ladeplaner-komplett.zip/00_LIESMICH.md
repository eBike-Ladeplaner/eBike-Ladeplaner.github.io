# eBike-Ladeplaner – alle Dateien

**Deutsch** · [English below](#english)

| Ordner | Wofür |
|---|---|
| `1_Webseite_GitHub` | Die Seite zum Hochladen bei GitHub Pages (Startbildschirm-App, auch offline). Anleitung in der README dort (Deutsch und Englisch). |
| `2_Shelly` | Skript für die Shelly-Steckdose (Taste = 1 Std. 30 Min., Webseite = genau bis zum Ziel). README auf Deutsch und Englisch. |
| `3_Tasmota` | Befehle für Tasmota-Steckdosen (gleiche Taste-Funktion über `PulseTime 5500`). README auf Deutsch und Englisch. |

Neu in dieser Version:
- **Version 86 (22.11.2026):**
  - **Info-Fenster nach einem Update:** Öffnet jemand die Seite nach einem Update, zeigt ein Fenster „Neu in der Version“ einmal, was sich geändert hat. Mit „Verstanden“ (oder Esc) schließt man es, danach kommt es erst bei der nächsten Version wieder. Beim allerersten Besuch erscheint es nicht, und während einer laufenden Ladung wartet es bis zum nächsten Öffnen. Bei jedem Build werden die Texte (DE + EN) in der Seite angepasst (`NEWS`, `NEWS_VER`).
- **Version 85 (22.11.2026):**
  - **Suchmaschinen:** Die Seite enthält jetzt den Hinweis „noindex, nofollow“, damit Suchmaschinen sie nicht aufnehmen. Das ist kein Zugangsschutz: Wer den Link kennt, kann die Seite öffnen. Schon erfasste Einträge verschwinden erst nach einiger Zeit.
  - **Feedback entfernt:** Den Button „Feedback“ (Version 84) gibt es nicht mehr. Der Abstand über der Sprachwahl ist wieder größer.
- **Version 84 (21.11.2026):**
  - **Feedback:** Unten über der Sprachwahl steht ein Button „Feedback“. Er öffnet das Google-Formular für Verbesserungsvorschläge in einem neuen Tab (die Seite und eine laufende Ladung bleiben offen). Ohne Internet funktioniert er nicht.
  - **Android-Hinweis:** Unter „Ablauf ohne Internet“ steht auf Android-Geräten zusätzlich: „Fragt Android, ob es verbunden bleiben soll, bestätige das.“ Auf iPhone und PC erscheint der Satz nicht (ungetestet auf echten Android-Geräten).
  - **Ladungsliste:** Die Markierung einer angetippten Ladung reicht jetzt bis zum Kartenrahmen, nicht darüber hinaus.
  - **Texte und Abstände:** „Nicht von Bosch.“ im Hinweis ganz unten entfernt (DE + EN). Die Abstände zwischen Hinweis, Version, Feedback und Sprachwahl sind kleiner.
- **Version 83 (20.11.2026):**
  - **Lernkurve:** Tippst du unter „Alle Ladungen anzeigen“ eine Ladung an, wird ihre Zeile eingefärbt und ihr Punkt im Diagramm orange markiert (mit Temperatur und Faktor). Hat die Ladung keinen Punkt (keine Temperatur, anderer Akku oder anderes Ladegerät), steht unter dem Diagramm eine kurze Meldung. Die Erklärungen stehen zugeklappt unter „Mehr zur Lernkurve“; außen steht nur ein kurzer Status („Noch keine Lernkurve …“ bzw. „10 Ladungen mit Temperatur im Diagramm“).
  - **Batterieschutz:** Ein von dir in der Seite abgebrochener Start zählt nicht, der Zähler geht auf den alten Stand zurück (auch bei einer abgebrochenen Batterieschutz-Ladung). Schaltest du die Steckdose von Hand aus, merkt die Seite das nicht. Der doppelte Satz im Hinweis ist weg.
  - **Texte:** „Hinweise“ gekürzt (Tasmota, Shelly, Deutsch + Englisch). „Mehr zur Sicherung“ und „Aus Versehen gelöscht?“ sind ein Hinweis. Die Korrekturfaktoren sind nur noch in der Lernkurve erklärt, klarer: bis 80 % Durchschnitt, ab 10 Ladungen mit Temperatur (mindestens 8 °C auseinander, heutige Temperatur höchstens 3 °C außerhalb) das Temperaturmodell; ab 80 % kein Temperaturmodell, der Faktor gilt ab 3 Ladungen, bei denen mindestens ein Drittel der Zeit über 80 % lag. Kurzanleitung gekürzt. „1 Ladung“ statt „1 Ladungen“.
- **Version 82 (18.11.2026):**
  - **„Verlauf“ einklappbar:** Wie „Akku & Ladegerät“. Zugeklappt steht die Zahl der Ladungen daneben („2 Ladungen“). Beim Öffnen der Seite ist die Karte immer zu; was du in einer Sitzung aufklappst, bleibt offen. „Sicherung“ (Als Datei sichern / Aus Datei wiederherstellen) bleibt immer sichtbar.
  - **Hinweis ganz unten:** „Privates Hobbyprojekt, ohne Gewähr. Nicht von Bosch. Lade den Akku nur unter Aufsicht, du schaltest auf eigene Verantwortung.“ (immer sichtbar, DE + EN)
- **Version 81 (18.11.2026):**
  - **Startprofil:** Gibt es beim Öffnen noch kein Profil, legt die Seite „Steckdose 1“ an (mit den aktuellen Einstellungen und dem bisherigen Verlauf). Das letzte Profil lässt sich nicht löschen (Knopf grau, Hinweis).
  - **„Laden bis“ 100 %:** Der Startknopf heißt „Batterieschutz 100 % starten“ und startet das Batterieschutz-Programm (2 A: 13 h, 4 A: 8 h, 6 A/12 A: 6 h). „Aktuell“ wird ignoriert, nichts im Verlauf, kein Lernen. Der Batterieschutz-Zähler springt auf 0.
  - **Zweiter Korrekturfaktor nur noch 80 bis 99 %:** Normale Ladungen gehen höchstens bis 99 %. Texte angepasst.
- **Version 80 (17.11.2026):**
  - **Profil bearbeiten und hinzufügen als Pop-up.** „Profil bearbeiten …“ zeigt oben „Welches Profil?“ mit allen Namen zum Antippen (bei mehr als einem Profil), darunter das Namensfeld, „Profil löschen“ (rot, links, mit Rückfrage „Wirklich löschen?“) und „Fertig“. Das aktive Profil bleibt dabei unverändert. „+ Profil hinzufügen“ fragt zuerst nach dem Namen („Anlegen“ erst mit Namen, „Abbrechen“ legt nichts an). „Profil löschen …“ in der Auswahl oben gibt es nicht mehr.
  - **Tastatur:** Alle Pop-ups passen ihre Höhe an die Fläche über der Tastatur an und lassen sich scrollen, damit die Knöpfe sichtbar bleiben.
  - **„Akku & Ladegerät“ und „Steckdose“:** Beim Öffnen der Seite sind beide zu. Was du in der Sitzung aufklappst, bleibt offen, bis du es selbst zuklappst (auch nach Änderungen und Profilwechsel).
- **Version 79 (17.11.2026):**
  - **Karte „Nach dem Laden“ entfernt.** Eingetragen wird über „Eintragen“ in der Karte oben, die das Pop-up öffnet. Korrigieren kannst du unter „Alle Ladungen anzeigen“ mit „Ändern“.
  - **Pop-up „Ladung eintragen“ kompakter:** Es steht ganz oben, mit engeren Abständen, und lässt sich scrollen. So verdeckt die Tastatur den Speichern-Knopf nicht mehr.
  - **Link ganz unten:** „Zum Home-Bildschirm hinzufügen“ (iPhone) bzw. „Zum Startbildschirm hinzufügen“ (Android) zeigt die Installationskarte wieder, falls du sie weggeklickt hast. Nicht am Computer und nicht in der installierten App.
  - **„Aus Versehen gelöscht?“:** Einklappbarer Hinweis unter „Alle Ladungen anzeigen“: Sicherungsdatei mit „Aus Datei wiederherstellen“ neu einlesen.
- **Version 78 (17.11.2026):** Tasmota im „WLAN der Steckdose“: Der Hinweis nennt jetzt die richtige Adresse 192.168.4.1 (Shelly: 192.168.33.1). Die Links nutzten sie schon vorher.
- **Version 77 (17.11.2026):**
  - **Shelly „Nach Verbrauch“:** Die Steckdose zeigt nach dem Tippen eine kleine Seite („Ladung gestartet“ mit Bereich und voraussichtlicher Zeit, „Steckdose aus“) und klare Fehlerseiten („Es fehlen Angaben“, „Schalten nicht möglich“, „Ziel zu niedrig“). **Das Shelly-Skript `01_lade_limit.js` muss dafür neu eingefügt werden.** Bei Shelly entfällt der Hinweis zum 2-Sekunden-Fenster (bei Tasmota bleibt er).
  - **Batterieschutz:** Graue Zeile „Batterieschutz: noch N Ladestarts“ auf der Hauptseite.
  - **„fertig morgen gegen HH:MM Uhr“,** wenn die Ladung nicht am selben Tag endet.
  - **Installationskarte:** iPhone: Text mit „Teilen-Fenster öffnen“ / „Später“. Android: „Installieren“ / „Nein danke“ (Fallback: Tipp mit Menü ⋮ und „OK“). Nicht am Computer und nicht, wenn die Seite schon als App läuft.
- **Version 76 (17.11.2026):**
  - **Sicherung aufgeräumt:** Unter „Sicherung“ steht eine orange Zeile („Noch nie gesichert · 5 Ladungen offen“), die Erklärung liegt hinter „Mehr zur Sicherung“. Der orangefarbene Doppelhinweis im Verlauf ist weg.
  - **„Nach dem Laden“ einklappbar:** Die Karte ist zu („Keine Ladung gemerkt“) und öffnet sich von selbst, wenn eine Ladung auf den Eintrag wartet oder „Eintragen“ getippt wird.
  - **„Ändern“ im Verlauf:** Unter „Alle Ladungen anzeigen“ hat jeder Eintrag „Ändern“ (nur der erreichte Ladestand, das Lernen nutzt den neuen Wert) und „Löschen“, untereinander.
  - **Rückfrage:** Liegt der erreichte Ladestand mehr als 20 Prozentpunkte unter dem Ziel, fragt die Seite „Wirklich … % speichern?“ („Nein, ändern“ / „Ja, speichern“).
  - **Temperatur:** Unter 0 °C oder über 40 °C erscheint eine Warnung (Bosch nennt für das Laden 0 bis 40 °C), ohne Sperre. „Kein Standort freigegeben …“ steht nur, solange das Temperaturfeld leer ist.
  - **Bildschirm bleibt an,** solange die Uhr läuft und die Seite sichtbar ist (wenn der Browser es erlaubt).
  - Texte gekürzt: Kurzanleitung, Hinweise, Lernkurve, Wirkungsgrad.
- **Profile:** Oben rechts wählst du das Profil. Jedes Profil ist eine Steckdose mit einem Akku und einem Ladegerät. Weitere Profile legst du mit „+ Profil hinzufügen“ an, umbenennen und löschen geht über „Profil bearbeiten …“ in der Auswahl. Mehrere Profile können gleichzeitig laden. Jede Ladung merkt sich ihr Profil. Der Verlauf und das Lernen gelten pro Profil: Jedes Profil sammelt und lernt nur aus seinen eigenen Ladungen.
- **Batterieschutz:** Unter „Akku & Ladegerät“ stellst du ein (voreingestellt: 10), nach wie vielen Ladestarts eine Ladung auf 100 % laufen soll (Balancing). Dann heißt der Knopf „Batterieschutz 100 % starten“ und startet einen Timer: Charger 2 A 13 Std., 4 A 8 Std., 6 A und 12 A 6 Std. Diese Ladung kommt nicht in den Verlauf.
- **Außentemperatur:** Die Seite trägt sie beim Öffnen von selbst ein (Internet und Standortfreigabe nötig). Der Knopf „Außentemperatur holen“ ist weg. Während der Suche zeigt ein kleiner Kreisel „Außentemperatur wird gesucht …“; bei Fehlschlag gibt es bis zu 3 Versuche und eine genaue Meldung (kein Standort, kein Internet, Wetterdienst nicht erreichbar). Bei Rückkehr in die Seite wird es erneut versucht. Das Feld lässt sich überschreiben.
- **Sicherung:** Die Datei enthält jetzt auch alle Profile mit ihren Einstellungen (Steckdose, IP, Akku, Ladegerät, Batterieschutz, Wirkungsgrad, Modus, letzter Ladestand). Alte Sicherungen lassen sich weiter einlesen; ihre Ladungen gehören dann zum gewählten Profil, und ist dort noch kein Akku/Ladegerät gewählt, werden Akku, Ladegerät, Kapazität und Leistung aus der jüngsten Ladung übernommen. Der Zählerstand des Batterieschutzes und die Temperatur werden nicht gesichert. Sind 3 oder mehr Ladungen seit der letzten Sicherung nicht als Datei gesichert, steht oben in einer kleinen Karte ein orangefarbener Hinweis mit der Zahl, dem Datum der letzten Sicherung und dem Knopf „Sichern“. Dabei springt die Seite nicht nach unten, die Rückmeldung erscheint in der Karte. Ist eine Ladung fertig und nicht gespeichert, steht dort auch „Eintragen“: Es öffnet ein Fenster, in dem du den erreichten Ladestand einträgst („Speichern“, „Abbrechen“, „Ladung verwerfen“ mit zweitem Tippen zur Bestätigung).
- **Zwei Korrekturfaktoren:** einer für 0 bis 80 %, einer für 80 bis 99 %, die Zeiten werden addiert. Jede gespeicherte Ladung füttert den Bereich, den sie berührt. Der Faktor ab 80 % wird erst ab 3 Ladungen über 80 % genutzt (vorher ×1,00). Das Temperaturmodell und die Lernkurve gelten nur bis 80 %. Tipp: Lade ab und zu von 80 auf 99 %.
- **Sprache:** Ganz unten auf der Seite wählst du „DE | EN“. Alle Texte gibt es auf Deutsch und Englisch. Beim ersten Öffnen richtet sich die Sprache nach dem Browser, danach gilt deine Wahl.
- Der Ordner `4_Einzeldatei` gibt es nicht mehr.

Früher dazugekommen: Charger 12 A (Leistung je Akku), Eingabefelder statt Schieberegler, „Laden bis“ 60 %, Taste an der Steckdose = 90 Minuten, Lernmodell mit Temperatur und Lernkurve, Anzeige „Im Akku jetzt / Dazu geladen / Im Akku danach“, Schutz-Overlay beim Zurückkehren in die Seite, Version unten auf der Seite.

Bedienung: Ein Knopf „Ladevorgang starten“ / „Ladevorgang abbrechen“. Beim Antippen geht der Befehl an die Steckdose (bei Tasmota erscheint dafür etwa 2 Sekunden ein kleines Fenster, das sich selbst schließt; bei Shelly zeigt die Steckdose eine kleine Antwortseite). Abbrechen schaltet die Steckdose aus und verwirft die gemerkte Ladung ohne Verlaufseintrag. Nach dem Laden tippst du oben auf „Eintragen“ und trägst im Pop-up nur den erreichten Ladestand ein.

Wichtig: Nichts davon ist an echter Shelly-/Tasmota-Hardware oder auf einem echten Handy getestet. Die Leistungswerte des Charger 12 A sind Näherungen aus Bosch-Ladezeiten.

---

<a id="english"></a>

# eBike Ladeplaner – all files

[Deutsch](#ebike-ladeplaner--alle-dateien)

| Folder | Purpose |
|---|---|
| `1_Webseite_GitHub` | The page to upload to GitHub Pages (home-screen app, works offline). Instructions in the README there (German and English). |
| `2_Shelly` | Script for the Shelly plug (button = 1 h 30 min, web page = exactly up to the target). README in German and English. |
| `3_Tasmota` | Commands for Tasmota plugs (same button function via `PulseTime 5500`). README in German and English. |

New in this version:
- **Version 86 (22 Nov 2026):**
  - **Info window after an update:** When someone opens the page after an update, a "New in this version" window shows once what has changed. Close it with "Got it" (or Esc); it returns only with the next version. It does not appear on the very first visit, and during a running charge it waits until the next time the page is opened. With every build the texts (DE + EN) in the page are updated (`NEWS`, `NEWS_VER`).
- **Version 85 (22 Nov 2026):**
  - **Search engines:** The page now contains the "noindex, nofollow" hint so search engines do not list it. This is not access protection: anyone who knows the link can open the page. Entries already indexed disappear only after some time.
  - **Feedback removed:** The "Feedback" button (version 84) is gone. The spacing above the language switch is larger again.
- **Version 84 (21 Nov 2026):**
  - **Feedback:** A "Feedback" button sits above the language switch at the bottom. It opens the Google form for suggestions in a new tab (the page and a running charge stay open). It does not work without internet.
  - **Android note:** Under "Ablauf ohne Internet" (flow without internet), Android devices additionally show: "If Android asks whether to stay connected, confirm." On iPhone and PC the sentence is not shown (not tested on real Android devices).
  - **Charge list:** The marking of a tapped charge now reaches the card frame, not beyond it.
  - **Texts and spacing:** "Not from Bosch." removed from the notice at the very bottom (DE + EN). The spacing between notice, version, feedback and language switch is smaller.
- **Version 83 (20 Nov 2026):**
  - **Learning curve:** Tap a charge under "Show all charges": its row is tinted and its dot in the chart turns orange (with temperature and factor). If the charge has no dot (no temperature, other battery or charger), a short message appears under the chart. The explanations are collapsed under "Mehr zur Lernkurve" (more about the learning curve); outside there is only a short status ("No learning curve yet …" or "10 charges with temperature in the chart").
  - **Battery protection:** A start you cancel in the page does not count; the counter goes back to the old value (also for a cancelled battery-protection charge). If you switch the plug off by hand, the page does not notice. The duplicated sentence in the note is gone.
  - **Texts:** "Hinweise" (notes) shortened (Tasmota, Shelly, German + English). "More about the backup" and "Deleted by mistake?" are one note. The correction factors are explained only in the learning-curve text, more clearly: up to 80 % the average, from 10 charges with temperature (at least 8 °C apart, today's temperature at most 3 °C outside) the temperature model; above 80 % no temperature model, the factor applies from 3 charges where at least a third of the time was above 80 %. Quick guide shortened. "1 charge" instead of "1 charges".
- **Version 82 (18 Nov 2026):**
  - **"Verlauf" (history) collapsible:** Like "Akku & Ladegerät" (battery and charger). When closed, the number of charges is shown next to it ("2 charges"). The card is always closed when the page opens; what you open during a session stays open. "Sicherung" (backup: save to file / restore from file) is always visible.
  - **Notice at the very bottom:** "Private hobby project, no warranty. Not from Bosch. Only charge the battery under supervision; you switch at your own risk." (always visible, DE + EN)
- **Version 81 (18 Nov 2026):**
  - **Start profile:** If there is no profile on opening, the page creates "Steckdose 1" (with the current settings and the existing history). The last profile cannot be deleted (button greyed out, note).
  - **"Laden bis" (charge to) 100 %:** The start button reads "Batterieschutz 100 % starten" and runs the battery-protection program (2 A: 13 h, 4 A: 8 h, 6 A/12 A: 6 h). "Aktuell" (current) is ignored, nothing goes into the history, no learning. The battery-protection counter resets to 0.
  - **Second correction factor only 80 to 99 %:** Normal charges go up to 99 % at most. Texts adjusted.
- **Version 80 (17 Nov 2026):**
  - **Edit profile and add profile as pop-ups.** "Profil bearbeiten …" (edit profile) shows "Which profile?" with all names to tap at the top (with more than one profile), below it the name field, "Profil löschen" (delete profile; red, left, with the confirmation "Wirklich löschen?") and "Fertig" (done). The active profile stays unchanged. "+ Profil hinzufügen" first asks for the name ("Anlegen" (create) only with a name, "Abbrechen" (cancel) creates nothing). "Profil löschen …" in the selector at the top is gone.
  - **Keyboard:** All pop-ups fit their height to the area above the keyboard and can scroll so the buttons stay visible.
  - **"Akku & Ladegerät" and "Steckdose":** Both are closed when the page opens. What you open during the session stays open until you close it yourself (also after changes and profile switches).
- **Version 79 (17 Nov 2026):**
  - **"Nach dem Laden" (after charging) card removed.** You enter the level via "Eintragen" (enter) in the card at the top, which opens the pop-up. You can correct it under "Show all charges" with "Change".
  - **Pop-up "Ladung eintragen" more compact:** It sits at the very top, with tighter spacing, and can scroll. The keyboard no longer hides the save button.
  - **Link at the very bottom:** "Add to Home Screen" (iPhone) or "Add to Home screen" (Android) shows the install card again if you dismissed it. Not on a computer and not in the installed app.
  - **"Deleted by mistake?":** Collapsible note under "Show all charges": read your backup file in again with "Restore from file".
- **Version 78 (17 Nov 2026):** Tasmota on the plug's own Wi-Fi: the note now shows the correct address 192.168.4.1 (Shelly: 192.168.33.1). The links already used it before.
- **Version 77 (17 Nov 2026):**
  - **Shelly "Nach Verbrauch" (by consumption):** After tapping, the plug shows a small page ("Ladung gestartet" (charge started) with range and expected time, "Steckdose aus" (plug off)) and clear error pages ("Es fehlen Angaben" (details missing), "Schalten nicht möglich" (cannot switch), "Ziel zu niedrig" (target too low)). **For this, paste the Shelly script `01_lade_limit.js` again.** For Shelly the hint about the 2-second window is gone (it stays for Tasmota).
  - **Battery protection:** Grey line "Batterieschutz: noch N Ladestarts" (N charge starts left) on the main page.
  - **"done tomorrow around HH:MM"** when the charge does not end on the same day.
  - **Install card:** iPhone: text with "Teilen-Fenster öffnen" (open share sheet) / "Später" (later). Android: "Installieren" (install) / "Nein danke" (no thanks); fallback: a tip with the menu ⋮ and "OK". Not on a computer and not if the page already runs as an app.
- **Version 76 (17 Nov 2026):**
  - **Backup tidied:** Under "Sicherung" (backup) there is one orange line ("Never backed up · 5 charges open"); the explanation is behind "More about the backup". The duplicate orange hint in the history is gone.
  - **"Nach dem Laden" (after charging) collapsible:** The card is closed ("No charge remembered") and opens by itself when a charge waits for its entry or "Eintragen" (enter) is tapped.
  - **"Change" in the history:** Under "Show all charges" each entry has "Change" (only the level reached; learning uses the new value) and "Delete", one below the other.
  - **Confirmation:** If the level reached is more than 20 percentage points below the target, the page asks "Really save … %?" ("No, change" / "Yes, save").
  - **Temperature:** Below 0 °C or above 40 °C a warning appears (Bosch gives 0 to 40 °C for charging), no blocking. "No location permission given …" only shows while the temperature field is empty.
  - **Screen stays on** while the clock runs and the page is visible (if the browser allows it).
  - Texts shortened: quick guide, hints, learning curve, efficiency.
- **Profiles:** Choose the profile at the top right. Each profile is one plug with one battery and one charger. Add profiles with "+ Profil hinzufügen" (add profile); rename or delete them via "Profil bearbeiten …" (edit profile) in the selector. Several profiles can charge at the same time. Each charge remembers its profile. History and learning are per profile: each profile collects and learns only from its own charges.
- **Battery protection:** Under "Akku & Ladegerät" (battery and charger) set (default: 10) after how many charge starts a charge to 100 % should run (balancing). Then the button reads "Batterieschutz 100 % starten" and starts a timer: Charger 2 A 13 h, 4 A 8 h, 6 A and 12 A 6 h. This charge is not saved to the history.
- **Outdoor temperature:** The page fills it in by itself when opened (needs internet and location permission). The "Außentemperatur holen" button is gone. While searching, a small spinner shows "Looking for the outdoor temperature …"; on failure it tries up to 3 times and gives a specific message (no location, no internet, weather service unreachable). It tries again when you return to the page. You can overwrite the field.
- **Backup:** The file now also contains all profiles with their settings (plug, IP, battery, charger, battery protection, efficiency, mode, last charge level). Old backups can still be imported; their charges then belong to the selected profile, and if no battery/charger is chosen there yet, battery, charger, capacity and power are taken from the latest charge. The battery-protection counter and the temperature are not backed up. If 3 or more charges have not been backed up as a file since the last backup, an orange notice in a small card at the top shows the number, the date of the last backup and a "Back up" button. The page does not jump down; the feedback appears in the card. If a charge is finished and not saved, the card also shows "Enter": it opens a window where you enter the level reached ("Save", "Cancel", "Discard charge" with a second tap to confirm).
- **Two correction factors:** one for 0 to 80 %, one for 80 to 99 %, the times are added. Each saved charge feeds the range it touches. The factor above 80 % is only used from 3 charges above 80 % (before that ×1.00). The temperature model and learning curve apply to the range up to 80 % only. Tip: charge from 80 to 99 % now and then.
- **Language:** At the very bottom of the page choose “DE | EN”. All texts exist in German and English. On first opening the language follows the browser, afterwards your choice applies.
- The folder `4_Einzeldatei` (single file) no longer exists.

Added earlier: Charger 12 A (power per battery), input fields instead of sliders, "Laden bis" (charge to) 60 %, button on the plug = 90 minutes, learning model with temperature and learning curve, display "in battery now / added / in battery after", protective overlay when returning to the page, version at the bottom of the page.

Usage: One button "Ladevorgang starten" (start charging) / "Ladevorgang abbrechen" (cancel). Tapping it sends the command to the plug (Tasmota: a small window for about 2 seconds that closes itself; Shelly: the plug shows a small reply page). Cancel switches the plug off and discards the remembered charge without a history entry. After charging, tap "Eintragen" (enter) at the top and enter only the level reached in the pop-up.

Important: None of this is tested on real Shelly/Tasmota hardware or on a real phone. The power values of the Charger 12 A are approximations from Bosch charging times.
